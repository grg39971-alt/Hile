# REYFIELD HUB — FC Mobile

Android app project. The main button opens the installed FC Mobile app. The Power Shot section is an informational practice helper; it does not modify the game, automate shots, or bypass game protections.

## Build APK using GitHub (phone-friendly)
1. Create a GitHub repository.
2. Upload the contents of this ZIP to the repository root (keep the `.github` folder).
3. Open the repository's **Actions** tab.
4. Select **Build REYFIELD APK** and press **Run workflow** (or wait for the push build).
5. Open the completed workflow run and download the **REYFIELD-FC-MOBILE-APK** artifact.
6. Extract the artifact ZIP; it contains `app-debug.apk`.

The workflow builds a debug APK. For public distribution, create a properly signed release build and protect your signing key.
