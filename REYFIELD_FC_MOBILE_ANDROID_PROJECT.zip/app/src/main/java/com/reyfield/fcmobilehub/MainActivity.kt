package com.reyfield.fcmobilehub

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val bg = Color.rgb(9, 11, 18)
    private val red = Color.rgb(255, 38, 70)
    private val muted = Color.rgb(158, 165, 181)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(30), dp(24), dp(24))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(35, 12, 23), bg, Color.rgb(10, 13, 22))
            )
        }

        val brand = label("REYFIELD", 24f, Color.WHITE, true).apply {
            letterSpacing = 0.18f
        }
        page.addView(brand, centeredWrap())

        val edition = label("FC MOBILE  •  HUB", 12f, muted, true).apply {
            letterSpacing = 0.16f
        }
        val editionParams = centeredWrap().apply { topMargin = dp(8) }
        page.addView(edition, editionParams)

        val spacer = LinearLayout(this)
        page.addView(spacer, LinearLayout.LayoutParams(1, 0, 1f))

        val title = label("POWER SHOT", 29f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            letterSpacing = 0.12f
        }
        page.addView(title, centeredWrap())

        val description = label(
            "Tek özellik • Şut antrenmanı yardımcısı", 13f, muted, false
        ).apply { gravity = Gravity.CENTER }
        page.addView(description, centeredWrap().apply {
            topMargin = dp(10); bottomMargin = dp(28)
        })

        val launch = Button(this).apply {
            text = "BAŞLAT  ↗"
            textSize = 17f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            isAllCaps = false
            background = rounded(red, 18)
            setPadding(dp(20), dp(15), dp(20), dp(15))
            setOnClickListener { openFcMobile() }
        }
        page.addView(launch, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(62)
        ))

        val info = label(
            "BAŞLAT, FC Mobile uygulamasını açar. Power Shot bölümü şut pratiği için bilgilendirici yardımcıdır; oyun dosyalarına veya çevrimiçi maçlara müdahale etmez.",
            11f, muted, false
        ).apply {
            gravity = Gravity.CENTER
            setLineSpacing(dp(4).toFloat(), 1f)
        }
        page.addView(info, centeredWrap().apply {
            topMargin = dp(22); bottomMargin = dp(18)
        })

        val footer = label("REYFIELD HUB  •  V1.0", 10f, Color.GRAY, true).apply {
            letterSpacing = 0.16f
        }
        page.addView(footer, centeredWrap())

        page.addView(spacer, LinearLayout.LayoutParams(1, 0, 1f))
        setContentView(page)
    }

    private fun openFcMobile() {
        val packageName = "com.ea.gp.fifamobile"
        val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
        if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(launchIntent)
        } else {
            Toast.makeText(
                this,
                "FC Mobile bulunamadı. Oyunun yüklü olduğundan emin ol.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean) =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun centeredWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { gravity = Gravity.CENTER_HORIZONTAL }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()
}
